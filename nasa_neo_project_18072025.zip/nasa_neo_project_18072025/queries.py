predefined_queries = {
    "Asteroid approach count": "SELECT name, COUNT(*) as approach_count FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id GROUP BY name;",
    "Average velocity per asteroid": "SELECT name, AVG(relative_velocity_kmph) as avg_velocity FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id GROUP BY name;",
    "Top 10 fastest asteroids": "SELECT name, MAX(relative_velocity_kmph) as max_velocity FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id GROUP BY name ORDER BY max_velocity DESC LIMIT 10;",
    "Hazardous asteroids > 3 approaches": "SELECT name FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id WHERE is_potentially_hazardous_asteroid = 1 GROUP BY name HAVING COUNT(*) > 3;",
    "Month with most approaches": "SELECT MONTH(close_approach_date) as month, COUNT(*) as count FROM close_approach GROUP BY month ORDER BY count DESC LIMIT 1;",
    "Fastest ever asteroid": "SELECT name, relative_velocity_kmph FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id ORDER BY relative_velocity_kmph DESC LIMIT 1;",
    "Asteroids by size (desc)": "SELECT name, estimated_diameter_max_km FROM asteroids ORDER BY estimated_diameter_max_km DESC;",
    "Closest approach trend": "SELECT name, close_approach_date, miss_distance_km FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id ORDER BY close_approach_date ASC, miss_distance_km ASC;",
    "Closest approach summary": "SELECT name, close_approach_date, miss_distance_km FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id;",
    "Velocity > 50000 km/h": "SELECT name, relative_velocity_kmph FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id WHERE relative_velocity_kmph > 50000;",
    "Monthly approach count": "SELECT MONTH(close_approach_date) as month, COUNT(*) as count FROM close_approach GROUP BY month;",
    "Highest brightness": "SELECT name, MIN(absolute_magnitude_h) as brightness FROM asteroids GROUP BY name ORDER BY brightness ASC LIMIT 1;",
    "Hazardous vs Non-hazardous": "SELECT is_potentially_hazardous_asteroid, COUNT(*) FROM asteroids GROUP BY is_potentially_hazardous_asteroid;",
    "Passed closer than Moon": "SELECT name, close_approach_date, miss_distance_lunar FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id WHERE miss_distance_lunar < 1;",
    "Came within 0.05 AU": "SELECT name, close_approach_date, astronomical FROM asteroids a JOIN close_approach c ON a.id = c.neo_reference_id WHERE astronomical < 0.05;"
}
