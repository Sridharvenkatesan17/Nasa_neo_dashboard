# streamlit_app.py
import streamlit as st
import pymysql
import pandas as pd
from config import MYSQL_CONFIG
from queries import predefined_queries

def get_connection():
    return pymysql.connect(**MYSQL_CONFIG)

def run_query(sql):
    conn = get_connection()
    df = pd.read_sql(sql, conn)
    conn.close()
    return df

# Page setup
st.set_page_config(page_title="NASA NEO Dashboard", layout="wide")
st.title("☄️ NASA Near-Earth Object (NEO) Dashboard")

# Sidebar: Predefined Queries
st.sidebar.header("🔍 Query Selection")
selected_query = st.sidebar.selectbox("Choose a predefined SQL query", list(predefined_queries.keys()))

if st.sidebar.button("Run Query"):
    query = predefined_queries[selected_query]
    result_df = run_query(query)
    st.subheader(f"Results: {selected_query}")
    st.dataframe(result_df)

# Sidebar: Filters
st.sidebar.markdown("---")
st.sidebar.header("📊 Custom Filters")

col1, col2 = st.columns(2)

with col1:
    date_filter = st.date_input("Close Approach After", format="YYYY-MM-DD")
    min_velocity = st.slider("Min Velocity (km/h)", 0, 100000, 1000, step=500)
    max_diameter = st.slider("Max Diameter (km)", 0.0, 10.0, 5.0)

with col2:
    lunar_distance = st.slider("Max Miss Distance (Lunar Units)", 0.0, 10.0, 1.0)
    hazardous = st.selectbox("Hazardous Only?", ("Both", "Yes", "No"))

# Run custom filtered query
if st.button("Apply Filters"):
    sql = f'''
    SELECT a.name, c.close_approach_date, c.relative_velocity_kmph, c.miss_distance_lunar,
           a.estimated_diameter_max_km, a.is_potentially_hazardous_asteroid
    FROM asteroids a
    JOIN close_approach c ON a.id = c.neo_reference_id
    WHERE c.close_approach_date >= '{date_filter}'
      AND c.relative_velocity_kmph >= {min_velocity}
      AND c.miss_distance_lunar <= {lunar_distance}
      AND a.estimated_diameter_max_km <= {max_diameter}
    '''
    if hazardous == "Yes":
        sql += " AND a.is_potentially_hazardous_asteroid = 1"
    elif hazardous == "No":
        sql += " AND a.is_potentially_hazardous_asteroid = 0"

    filtered_df = run_query(sql)
    st.subheader("Filtered Asteroid Approaches")
    st.dataframe(filtered_df)
