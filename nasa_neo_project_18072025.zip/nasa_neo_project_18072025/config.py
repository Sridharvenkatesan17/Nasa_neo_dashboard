# config.py

NASA_API_KEY = 'd0XeIYJc3KNbheRpcQ4plvBlsGat0uzkZ6sV5yMp'

MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",  # change this if needed
    "password": "Minnie@008",  # change this to your MySQL password
    "database": "nasa_neo"
}
