import requests
import json
from config import NASA_API_KEY

def fetch_neo_data(start_date="2024-01-01", max_records=10000):
    url = f"https://api.nasa.gov/neo/rest/v1/feed?start_date={start_date}&api_key={NASA_API_KEY}"
    records = []
    count = 0

    while len(records) < max_records:
        print(f"Fetching from: {url}")
        response = requests.get(url)
        if response.status_code != 200:
            print("❌ Error:", response.status_code, response.text)
            break

        data = response.json()
        for date in data['near_earth_objects']:
            for obj in data['near_earth_objects'][date]:
                records.append(obj)
                count += 1
                if count >= max_records:
                    break
            if count >= max_records:
                break

        next_link = data['links'].get('next')
        if not next_link:
            break
        url = next_link

    # Save to file
    with open("neo_data.json", "w") as f:
        json.dump(records, f, indent=2)

    print(f"✅ Fetched {len(records)} records successfully.")

# Run the function
if __name__ == "__main__":
    fetch_neo_data()
