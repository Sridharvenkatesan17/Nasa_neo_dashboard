import pymysql
from config import MYSQL_CONFIG
from data_cleaner import clean_data

def init_db():
    conn = pymysql.connect(**MYSQL_CONFIG)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS asteroids (
            id BIGINT,
            name VARCHAR(255),
            absolute_magnitude_h FLOAT,
            estimated_diameter_min_km FLOAT,
            estimated_diameter_max_km FLOAT,
            is_potentially_hazardous_asteroid BOOLEAN
        );
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS close_approach (
            neo_reference_id BIGINT,
            close_approach_date DATE,
            relative_velocity_kmph FLOAT,
            astronomical FLOAT,
            miss_distance_km FLOAT,
            miss_distance_lunar FLOAT,
            orbiting_body VARCHAR(50)
        );
    """)

    asteroids, approaches = clean_data()

    for a in asteroids:
        cursor.execute("""
            INSERT INTO asteroids (id, name, absolute_magnitude_h, estimated_diameter_min_km,
            estimated_diameter_max_km, is_potentially_hazardous_asteroid) VALUES (%s, %s, %s, %s, %s, %s)
        """, tuple(a.values()))

    for ca in approaches:
        cursor.execute("""
            INSERT INTO close_approach (neo_reference_id, close_approach_date, relative_velocity_kmph, astronomical,
            miss_distance_km, miss_distance_lunar, orbiting_body) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, tuple(ca.values()))

    conn.commit()
    cursor.close()
    conn.close()
    print("Database initialized and data inserted successfully.")

if __name__ == "__main__":
    print("Running database initializer...")
    init_db()
    print("✅ Done!")