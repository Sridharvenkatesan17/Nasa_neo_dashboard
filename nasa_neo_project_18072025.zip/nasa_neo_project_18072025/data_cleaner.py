import json
from datetime import datetime

def clean_data(input_file="neo_data.json"):
    with open(input_file) as f:
        raw_data = json.load(f)

    asteroids = []
    approaches = []

    for obj in raw_data:
        est_dia = obj['estimated_diameter']['kilometers']
        approach_data = obj['close_approach_data'][0]
        asteroid = {
            "id": int(obj['id']),
            "name": obj['name'],
            "absolute_magnitude_h": float(obj['absolute_magnitude_h']),
            "estimated_diameter_min_km": float(est_dia['estimated_diameter_min']),
            "estimated_diameter_max_km": float(est_dia['estimated_diameter_max']),
            "is_potentially_hazardous_asteroid": obj['is_potentially_hazardous_asteroid']
        }
        asteroids.append(asteroid)

        approach = {
            "neo_reference_id": int(obj['id']),
            "close_approach_date": datetime.strptime(approach_data['close_approach_date'], "%Y-%m-%d").date(),
            "relative_velocity_kmph": float(approach_data['relative_velocity']['kilometers_per_hour']),
            "astronomical": float(approach_data['miss_distance']['astronomical']),
            "miss_distance_km": float(approach_data['miss_distance']['kilometers']),
            "miss_distance_lunar": float(approach_data['miss_distance']['lunar']),
            "orbiting_body": approach_data['orbiting_body']
        }
        approaches.append(approach)

    return asteroids, approaches
